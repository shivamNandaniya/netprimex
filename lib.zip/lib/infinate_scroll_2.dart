import 'package:flutter/material.dart';

class InfiniteMovieGrid1 extends StatelessWidget {
  final List<String> imageUrls;
  final int rowCount;
  final double speed;

  const InfiniteMovieGrid1({
    super.key,
    required this.imageUrls,
    this.rowCount = 8,
    this.speed = 40,
  }) : assert(imageUrls.length > 0),
        assert(rowCount > 0),
        assert(speed > 0);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: const Color(0xFF0A0E27), // Dark background like reference
      child: Transform(
        alignment: Alignment.center,
        transform: Matrix4.identity()
          ..setEntry(3, 2, 0.0008) // Perspective
          ..rotateX(-0.7) // More cross angle
          ..rotateY(-0.25) // More side cross angle
          ..rotateZ(0.12) // Additional rotation for more cross effect
          ..scale(1.6), // Bigger scale to fill screen
        child: Column(
          children: List.generate(
            rowCount,
                (rowIndex) => Expanded(
              child: InfiniteScrollRow(
                imageUrls: imageUrls,
                rowIndex: rowIndex,
                rowCount: rowCount,
                speed: speed,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class InfiniteScrollRow extends StatefulWidget {
  final List<String> imageUrls;
  final int rowIndex;
  final int rowCount;
  final double speed;

  const InfiniteScrollRow({
    super.key,
    required this.imageUrls,
    required this.rowIndex,
    required this.rowCount,
    required this.speed,
  });

  @override
  State<InfiniteScrollRow> createState() => _InfiniteScrollRowState();
}

class _InfiniteScrollRowState extends State<InfiniteScrollRow>
    with SingleTickerProviderStateMixin {
  late final ScrollController _controller;
  late final List<String> _sequence;
  late final double _itemWidth;
  late final double _spacing;
  late final double _maxScroll;

  @override
  void initState() {
    super.initState();
    _itemWidth = 110;
    _spacing = 6;

    // Create extended sequence for seamless infinite scroll
    final total = widget.imageUrls.length;
    final chunkSize = (total / widget.rowCount).ceil();
    final start = (widget.rowIndex * chunkSize) % total;

    List<String> baseSequence = List.generate(
      chunkSize,
          (i) => widget.imageUrls[(start + i) % total],
    );

    // Extend sequence 5 times for smooth infinite scroll
    _sequence = [];
    for (int i = 0; i < 5; i++) {
      _sequence.addAll(baseSequence);
    }

    _maxScroll = (_sequence.length / 2.5) * (_itemWidth + _spacing);

    // OPPOSITE SIDE CROSS MOVEMENT
    // Even rows start from right, go left (opposite of reference)
    // Odd rows start from left, go right
    final initialOffset = widget.rowIndex.isEven ? _maxScroll : 0.0;
    _controller = ScrollController(initialScrollOffset: initialOffset);

    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollLoop());
  }

  Future<void> _scrollLoop() async {
    while (mounted) {
      try {
        // OPPOSITE DIRECTION CROSS MOVEMENT
        final isRightToLeft = widget.rowIndex.isEven; // Changed logic
        final from = isRightToLeft ? _maxScroll : 0.0;
        final to = isRightToLeft ? 0.0 : _maxScroll;

        final duration = Duration(
          milliseconds: ((_maxScroll / widget.speed) * 1200).round(),
        );

        if (_controller.hasClients) {
          _controller.jumpTo(from);
          await _controller.animateTo(
            to,
            duration: duration,
            curve: Curves.linear,
          );
        }

        await Future.delayed(const Duration(milliseconds: 100));
      } catch (e) {
        break;
      }
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: double.infinity,
      padding: EdgeInsets.symmetric(vertical: 1),
      // Additional transform for each row to increase cross effect
      child: Transform(
        alignment: Alignment.center,
        transform: Matrix4.identity()
          ..rotateZ(widget.rowIndex.isEven ? 0.05 : -0.05), // More cross angle per row
        child: ListView.builder(
          controller: _controller,
          scrollDirection: Axis.horizontal,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: _sequence.length,
          itemBuilder: (context, index) {
            final url = _sequence[index];
            return Container(
              width: _itemWidth,
              margin: EdgeInsets.only(right: _spacing),
              // Additional transform for each poster
              child: Transform(
                alignment: Alignment.center,
                transform: Matrix4.identity()
                  ..rotateY(0.08) // Individual poster angle
                  ..rotateX(0.02),
                child: _buildMoviePoster(url),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildMoviePoster(String imageUrl) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 8,
            offset: const Offset(0, 4),
            spreadRadius: 1,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Image.network(
          imageUrl,
          fit: BoxFit.cover,
          width: double.infinity,
          height: double.infinity,
          errorBuilder: (_, __, ___) => Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.grey.shade800,
                  Colors.grey.shade900,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.movie,
              color: Colors.grey,
              size: 26,
            ),
          ),
        ),
      ),
    );
  }
}
