import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'infinite_grid.dart'; // Your file name

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _logoController;
  late AnimationController _fadeController;
  late Animation<double> _logoScale;
  late Animation<double> _logoFade;
  late Animation<double> _overlayFade;
  Timer? _navigationTimer;

  @override
  void initState() {
    super.initState();

    _logoController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _logoScale = Tween<double>(
      begin: 0.5,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _logoController,
      curve: Curves.elasticOut,
    ));

    _logoFade = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _logoController,
      curve: const Interval(0.0, 0.6, curve: Curves.easeIn),
    ));

    _overlayFade = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    ));

    _startAnimations();
  }

  void _startAnimations() async {
    _fadeController.forward();
    await Future.delayed(const Duration(milliseconds: 300));
    _logoController.forward();

    _navigationTimer = Timer(const Duration(seconds: 3), () {
      if (mounted) {
        // Navigate to your home screen
        print("Navigate to home");
      }
    });
  }

  @override
  void dispose() {
    _logoController.dispose();
    _fadeController.dispose();
    _navigationTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      body: Stack(
        children: [
          // More cross diagonal movie grid
          InfiniteMovieGrid(
            imageUrls: [
              "https://m.media-amazon.com/images/M/MV5BNzgzMTQ0NTgtOGRjMi00YWIxLTk0MjYtMjYwNjM4Y2I0MThjXkEyXkFqcGc@._V1_.jpg",
              "https://cdn.europosters.eu/image/hp/116547.jpg",
              "https://d1csarkz8obe9u.cloudfront.net/posterpreviews/movie-poster-template-design-21a1c803fe4ff4b858de24f5c91ec57f_screen.jpg?ts=1636996180",
              "https://creativereview.imgix.net/content/uploads/2024/12/AlienRomulus-scaled.jpg?auto=compress,format&q=60&w=1728&h=2560",
              "https://i.pinimg.com/originals/fb/55/dc/fb55dc632b7a7ffbabf104b1208b27fc.jpg",
              "https://i1.wp.com/www.shutterstock.com/blog/wp-content/uploads/sites/5/2024/03/Dune-movie-poster.jpg?ssl=1",
              "https://i.pinimg.com/736x/98/36/e4/9836e4e145b656371e550e1ba252a582.jpg",
              "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQah7rvAdEmDnkxXIIQ0KqbE0gjKPQvnL77xQ&s",
              "https://images-cdn.ubuy.co.in/633cae2eb5f1fa3ed74f58ac-titanic-movie-poster-leonardo-dicaprio.jpg",
              "https://cdn.prod.website-files.com/6009ec8cda7f305645c9d91b/66a4263d01a185d5ea22eeef_6408f676b5811234c887ca62_top%2520gun%2520maverick-min.png",
            ],
            rowCount: 8,
            speed: 25, // Slower for cinematic effect
          ),

          // Gradient overlay
          AnimatedBuilder(
            animation: _overlayFade,
            builder: (context, child) {
              return Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.center,
                    radius: 1.0,
                    colors: [
                      Colors.transparent,
                      const Color(0xFF0A0E27).withOpacity(0.6 * _overlayFade.value),
                      const Color(0xFF0A0E27).withOpacity(0.9 * _overlayFade.value),
                    ],
                  ),
                ),
              );
            },
          ),

          // Logo
          Center(
            child: AnimatedBuilder(
              animation: Listenable.merge([_logoScale, _logoFade]),
              builder: (context, child) {
                return Transform.scale(
                  scale: _logoScale.value,
                  child: Opacity(
                    opacity: _logoFade.value,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(24),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                        child: Container(
                          padding: const EdgeInsets.all(40),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.6),
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.15),
                            ),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 90,
                                height: 90,
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [Color(0xFFFF6B6B), Color(0xFFFF8E53)],
                                  ),
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: [
                                    BoxShadow(
                                      color: const Color(0xFFFF6B6B).withOpacity(0.4),
                                      blurRadius: 20,
                                      offset: const Offset(0, 8),
                                    ),
                                  ],
                                ),
                                child: const Icon(
                                  Icons.movie,
                                  color: Colors.white,
                                  size: 45,
                                ),
                              ),
                              const SizedBox(height: 20),
                              const Text(
                                "Reevie",
                                style: TextStyle(
                                  fontSize: 36,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                  letterSpacing: 2,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                "Movie Reviews & Ratings",
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.white.withOpacity(0.8),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
