import 'package:flutter/material.dart';

class InfiniteMovieGrid extends StatelessWidget {
  final List<String> imageUrls;
  final int rowCount;
  final double speed;

  const InfiniteMovieGrid({
    super.key,
    required this.imageUrls,
    this.rowCount = 5,
    this.speed = 40,
  }) : assert(imageUrls.length > 0),
        assert(rowCount > 0),
        assert(speed > 0);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(
        rowCount,
            (rowIndex) => Expanded(
          child: InfiniteScrollRow(
            imageUrls: imageUrls,
            rowIndex: rowIndex,
            rowCount: rowCount,
            speed: speed,
            // KEY CHANGE: Pass scroll direction based on row index
            scrollDirection: rowIndex.isEven
                ? ScrollDirection.leftToRight
                : ScrollDirection.rightToLeft,
          ),
        ),
      ),
    );
  }
}

enum ScrollDirection { leftToRight, rightToLeft }

class InfiniteScrollRow extends StatefulWidget {
  final List<String> imageUrls;
  final int rowIndex;
  final int rowCount;
  final double speed;
  final ScrollDirection scrollDirection; // NEW PARAMETER

  const InfiniteScrollRow({
    super.key,
    required this.imageUrls,
    required this.rowIndex,
    required this.rowCount,
    required this.speed,
    required this.scrollDirection, // REQUIRED NOW
  });

  @override
  State<InfiniteScrollRow> createState() => _InfiniteScrollRowState();
}

class _InfiniteScrollRowState extends State<InfiniteScrollRow> {
  late final ScrollController _controller;
  late final List<String> _sequence;
  late final double _itemWidth;
  late final double _spacing;
  late final double _maxScroll;

  @override
  void initState() {
    super.initState();
    _itemWidth = 120;
    _spacing = 8;

    // Determine chunk size and sequence for this row
    final total = widget.imageUrls.length;
    final chunkSize = (total + widget.rowCount - 1) ~/ widget.rowCount;
    final start = (widget.rowIndex * chunkSize) % total;
    _sequence = List.generate(
      chunkSize,
          (i) => widget.imageUrls[(start + i) % total],
    );

    // Compute scrollable distance
    _maxScroll = _sequence.length * (_itemWidth + _spacing);

    // UPDATED: Set initial position based on scroll direction
    final initialOffset = widget.scrollDirection == ScrollDirection.leftToRight
        ? 0.0
        : _maxScroll;

    _controller = ScrollController(initialScrollOffset: initialOffset);

    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollLoop());
  }

  Future<void> _scrollLoop() async {
    while (mounted) {
      // UPDATED: Define scroll direction based on enum
      final bool isLeftToRight = widget.scrollDirection == ScrollDirection.leftToRight;

      final from = isLeftToRight ? 0.0 : _maxScroll;
      final to = isLeftToRight ? _maxScroll : 0.0;

      final duration = Duration(
        milliseconds: ((_maxScroll / widget.speed) * 1000).round(),
      );

      // Reset position and animate
      _controller.jumpTo(from);
      await _controller.animateTo(to, duration: duration, curve: Curves.linear);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      controller: _controller,
      scrollDirection: Axis.horizontal,
      physics: const NeverScrollableScrollPhysics(),
      reverse: false,
      itemCount: _sequence.length * 3, // Increased for seamless loop
      itemBuilder: (context, index) {
        final url = _sequence[index % _sequence.length];
        return Padding(
          padding: EdgeInsets.only(right: _spacing),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8), // Added rounded corners
            child: Image.network(
              url,
              width: _itemWidth,
              height: double.infinity,
              fit: BoxFit.cover, // Changed to cover for better poster display
              errorBuilder: (_, __, ___) => Container(
                width: _itemWidth,
                decoration: BoxDecoration(
                  color: Colors.grey.shade800,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Center(
                  child: Icon(
                    Icons.broken_image,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
